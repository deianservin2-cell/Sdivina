# El Rey del Número — homebrew PS4 (OpenOrbis)

Elegís un número, el juego "intenta adivinarlo" y falla, y después se abre el combate contra el Rey de ese número.
Más número = jefe con más vida y más balas. Si ganás, trofeo (dentro del juego).

## Controles
- Menú: ←/→ cambiar número, ✕ confirmar
- Combate: stick izquierdo o cruceta para moverte, ✕ para disparar

## Compilar
1. Instalá el toolchain OpenOrbis y definí `OO_PS4_TOOLCHAIN` (ruta a su carpeta).
2. Necesitás clang y lld (LLVM) en el PATH.
3. Desde esta carpeta: `make`
4. Sale `IV0000-NUMR00001_00-REYDELNUMERO0001.pkg`.

## Importante (leer)
- Este código NO está probado en consola: lo escribí sin poder compilar acá. Las APIs (VideoOut, Pad, UserService) siguen
  los ejemplos de OpenOrbis, pero si algún nombre o ruta de herramienta difiere en tu versión, compará con las carpetas
  `samples/` del toolchain (sobre todo los ejemplos de gráficos y controller) y ajustá `src/main.c` y el `Makefile`.
- Si el pad no responde, puede faltar cargar módulos con sysmodule, como hacen los ejemplos de controller.
- Algunas versiones del toolchain piden además `sce_sys/about/right.sprx` (viene en los samples): copialo y agregalo
  a la lista de archivos de `pkg.gp4` en el Makefile.
- Corre solo en una PS4 con jailbreak/homebrew habilitado. Los trofeos son dibujados por el juego; los trofeos reales de
  PSN requieren juegos con licencia de Sony.
