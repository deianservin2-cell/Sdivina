/* EL REY DEL NUMERO - homebrew PS4 (OpenOrbis). Render por software al framebuffer 1920x1080. */
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <orbis/libkernel.h>
#include <orbis/VideoOut.h>
#include <orbis/Pad.h>
#include <orbis/UserService.h>
#include "font.h"

#define FBW 1920
#define FBH 1080
#define S 2                 /* el mundo del juego es 960x540, se escala x2 */
#define WW 960
#define WH 540

static int video, pad;
static void *fbs[2];
static uint32_t *fb;

/* ---------- video ---------- */
static void init_video(void){
    video = sceVideoOutOpen(ORBIS_USER_SERVICE_USER_ID_SYSTEM, ORBIS_VIDEO_OUT_BUS_TYPE_MAIN, 0, NULL);
    size_t one = 0x800000, total = one * 2;          /* 8MB por buffer (alineado a 2MB) */
    off_t phys = 0; void *base = NULL;
    sceKernelAllocateDirectMemory(0, sceKernelGetDirectMemorySize(), total, 0x200000, 3, &phys);
    sceKernelMapDirectMemory(&base, total, 0x33, 0, phys, 0x200000);
    fbs[0] = base; fbs[1] = (char*)base + one;
    OrbisVideoOutBufferAttribute attr;
    sceVideoOutSetBufferAttribute(&attr, ORBIS_VIDEO_OUT_PIXEL_FORMAT_B8_G8_R8_A8_SRGB,
        ORBIS_VIDEO_OUT_TILING_MODE_LINEAR, ORBIS_VIDEO_OUT_ASPECT_RATIO_16_9, FBW, FBH, FBW);
    sceVideoOutRegisterBuffers(video, 0, fbs, 2, &attr);
    sceVideoOutSetFlipRate(video, 0);
}

/* ---------- dibujo (coordenadas del mundo 960x540) ---------- */
static void rect(int x,int y,int w,int h,uint32_t c){
    x*=S;y*=S;w*=S;h*=S;
    if(x<0){w+=x;x=0;} if(y<0){h+=y;y=0;}
    if(x+w>FBW)w=FBW-x; if(y+h>FBH)h=FBH-y;
    for(int j=0;j<h;j++){uint32_t*p=fb+(y+j)*FBW+x;for(int i=0;i<w;i++)p[i]=c;}
}
static void circle(int cx,int cy,int r,uint32_t c){
    for(int j=-r;j<=r;j++){int w=(int)sqrtf((float)(r*r-j*j));rect(cx-w,cy+j,2*w+1,1,c);}
}
static void tri(int x,int y,uint32_t c){ /* nave del jugador */
    for(int j=0;j<20;j++){int w=j/2;rect(x-w,y-12+j,2*w+1,1,c);}
}
static void text(int x,int y,const char*s,int sc,uint32_t c){
    for(;*s;s++,x+=6*sc){
        int ch=*s; if(ch<32||ch>95)ch=32;
        for(int col=0;col<5;col++){unsigned char b=FONT5x7[ch-32][col];
            for(int row=0;row<7;row++) if(b&(1<<row)) rect(x+col*sc,y+row*sc,sc,sc,c);}
    }
}
static void text_c(int y,const char*s,int sc,uint32_t c){
    int w=(int)strlen(s)*6*sc-sc; text((WW-w)/2,y,s,sc,c);
}

/* ---------- input ---------- */
static uint32_t btn, prev;
static float ax, ay;
static void read_pad(void){
    OrbisPadData d; prev=btn; ax=ay=0;
    if(scePadReadState(pad,&d)==0){
        btn=d.buttons;
        ax=((int)d.leftStick.x-128)/128.0f; ay=((int)d.leftStick.y-128)/128.0f;
        if(fabsf(ax)<0.2f)ax=0; if(fabsf(ay)<0.2f)ay=0;
        if(btn&ORBIS_PAD_BUTTON_LEFT)ax=-1; if(btn&ORBIS_PAD_BUTTON_RIGHT)ax=1;
        if(btn&ORBIS_PAD_BUTTON_UP)ay=-1;   if(btn&ORBIS_PAD_BUTTON_DOWN)ay=1;
    }
}
static int pressed(uint32_t b){return (btn&b)&&!(prev&b);}

/* ---------- juego ---------- */
typedef struct {float x,y,vx,vy;int on;} Bul;
#define MAXB 700
static Bul bul[MAXB], shots[64];
enum {ST_PICK,ST_DIALOG,ST_FIGHT,ST_WIN,ST_LOSE};
static int st=ST_PICK, num=7;
static char lines[7][48]; static int dlg=0, dlgT=0;
static float px,py,inv,bx,by=110,bdir=1,bang,bt,at,cd;
static int lives,bhp,bmax;
static uint32_t rng=12345;
static int rnd(int n){rng=rng*1103515245u+12345u;return (int)((rng>>16)%(unsigned)n);}

static void start_dialog(void){
    int w[3],k=0;
    while(k<3){int r=1+rnd(10),ok=(r!=num);for(int i=0;i<k;i++)if(w[i]==r)ok=0;if(ok)w[k++]=r;}
    snprintf(lines[0],48,"MMM... PENSANDO...");
    for(int i=0;i<3;i++)snprintf(lines[1+i],48,"ES EL %d?  ...NO.",w[i]);
    snprintf(lines[4],48,"ES EL %d? OBVIO QUE SI!",num);
    snprintf(lines[5],48,"BUENO... AHORA SI, ALGO EN SERIO.");
    snprintf(lines[6],48,"EL REY %d DESPERTO!",num);
    dlg=0;dlgT=0;st=ST_DIALOG;
}
static void start_fight(void){
    memset(bul,0,sizeof bul);memset(shots,0,sizeof shots);
    px=WW/2;py=WH-60;lives=5;inv=0;bx=WW/2;bdir=1;bang=0;bt=at=cd=0;
    bmax=bhp=30+num*6; st=ST_FIGHT;
}
static void add_bul(float x,float y,float vx,float vy){
    for(int i=0;i<MAXB;i++)if(!bul[i].on){bul[i]=(Bul){x,y,vx,vy,1};return;}
}
static void fight_update(float dt,int fire){
    px+=ax*340*dt; py+=ay*340*dt;
    if(px<10)px=10; if(px>WW-10)px=WW-10; if(py<220)py=220; if(py>WH-10)py=WH-10;
    cd-=dt; if(fire&&cd<=0){for(int i=0;i<64;i++)if(!shots[i].on){shots[i]=(Bul){px,py-10,0,-780,1};break;} cd=0.16f;}
    for(int i=0;i<64;i++)if(shots[i].on){shots[i].y+=shots[i].vy*dt;
        if(shots[i].y<-10)shots[i].on=0;
        else if(hypotf(shots[i].x-bx,shots[i].y-by)<50){bhp--;shots[i].on=0;}}
    bx+=bdir*(105+num*8)*dt; if(bx>WW-70)bdir=-1; if(bx<70)bdir=1;
    bt+=dt; if(bt>1.5f){bt=0;int k=num+5;if(k<6)k=6;bang+=0.4f;
        for(int i=0;i<k;i++){float a=bang+i*6.2831853f/k,v=165+num*9;add_bul(bx,by,cosf(a)*v,sinf(a)*v);}}
    at+=dt; if(at>1.1f){at=0;float a=atan2f(py-by,px-bx);add_bul(bx,by,cosf(a)*330,sinf(a)*330);}
    inv-=dt;
    for(int i=0;i<MAXB;i++)if(bul[i].on){Bul*b=&bul[i];b->x+=b->vx*dt;b->y+=b->vy*dt;
        if(b->x<-20||b->x>WW+20||b->y<-20||b->y>WH+20){b->on=0;continue;}
        if(inv<=0&&hypotf(b->x-px,b->y-py)<14){lives--;inv=1.2f;b->on=0;}}
    if(bhp<=0)st=ST_WIN; else if(lives<=0)st=ST_LOSE;
}

static void draw_trophy(int cx,int y){
    uint32_t g=0xFFFFCC33;
    rect(cx-40,y,80,60,g); rect(cx-60,y+10,20,10,g); rect(cx+40,y+10,20,10,g);
    rect(cx-10,y+60,20,30,g); rect(cx-35,y+90,70,14,g);
    circle(cx,y+30,10,0xFFFFEE88);
}
static void render(void){
    rect(0,0,WW,WH,0xFF0A0A14);
    if(st==ST_PICK){
        text_c(60,"EL REY DEL NUMERO",5,0xFFFFCC33);
        text_c(170,"ELEGI UN NUMERO DEL 1 AL 10",3,0xFFFFFFFF);
        char b[8];snprintf(b,8,"%d",num);text_c(240,b,14,0xFF33DDFF);
        text_c(400,"IZQ/DER: CAMBIAR     X: CONFIRMAR",2,0xFFAAAAAA);
    } else if(st==ST_DIALOG){
        text_c(230,lines[dlg],3,0xFFFFFFFF);
    } else if(st==ST_FIGHT){
        circle((int)bx,(int)by,50,0xFF6A1B9A);
        char b[8];snprintf(b,8,"%d",num);text((int)bx-(num>9?30:15),(int)by-14,b,5,0xFFFFCC33);
        rect((int)bx-24,(int)by-72,48,10,0xFFFFCC33);
        for(int i=0;i<3;i++)rect((int)bx-24+i*20,(int)by-82,8,10,0xFFFFCC33);
        for(int i=0;i<64;i++)if(shots[i].on)rect((int)shots[i].x-2,(int)shots[i].y-8,4,14,0xFFFFE066);
        for(int i=0;i<MAXB;i++)if(bul[i].on)circle((int)bul[i].x,(int)bul[i].y,6,0xFFFF4466);
        if(inv<=0||((int)(inv*10))%2)tri((int)px,(int)py,0xFF33DDFF);
        rect(160,12,640,16,0xFF333333); rect(160,12,640*(bhp>0?bhp:0)/bmax,16,0xFFE53935);
        char t[24];snprintf(t,24,"REY %d",num);text(20,14,t,2,0xFFFFFFFF);
        for(int i=0;i<lives;i++)circle(WW-30-i*26,WH-24,9,0xFFFF4466);
    } else if(st==ST_WIN){
        draw_trophy(WW/2,90);
        text_c(230,"TROFEO DESBLOQUEADO",4,0xFFFFCC33);
        char t[40];snprintf(t,40,"REGICIDA DEL %d",num);text_c(290,t,4,0xFFFFFFFF);
        text_c(420,"X: JUGAR DE NUEVO",2,0xFFAAAAAA);
    } else {
        text_c(200,"EL REY TE APLASTO",4,0xFFFF4466);
        text_c(270,"ES DIFICIL, PERO SE PUEDE GANAR",2,0xFFFFFFFF);
        text_c(400,"X: REINTENTAR",2,0xFFAAAAAA);
    }
}

int main(void){
    init_video();
    sceUserServiceInitialize(NULL);
    int uid=0; sceUserServiceGetInitialUser(&uid);
    scePadInit(); pad=scePadOpen(uid,0,0,NULL);
    rng=(uint32_t)sceKernelGetProcessTime();
    int idx=0;
    for(;;){
        read_pad();
        switch(st){
        case ST_PICK:
            if(pressed(ORBIS_PAD_BUTTON_LEFT)&&num>1)num--;
            if(pressed(ORBIS_PAD_BUTTON_RIGHT)&&num<10)num++;
            if(pressed(ORBIS_PAD_BUTTON_CROSS))start_dialog();
            break;
        case ST_DIALOG:
            if(++dlgT>100){dlgT=0;if(++dlg>6)start_fight();}
            break;
        case ST_FIGHT: fight_update(1.0f/60,(btn&ORBIS_PAD_BUTTON_CROSS)!=0); break;
        default:
            if(pressed(ORBIS_PAD_BUTTON_CROSS)){ if(st==ST_WIN)st=ST_PICK; else start_fight(); }
        }
        fb=(uint32_t*)fbs[idx]; render();
        sceVideoOutSubmitFlip(video,idx,ORBIS_VIDEO_OUT_FLIP_VSYNC,0);
        idx^=1; sceKernelUsleep(16000);
    }
    return 0;
}
